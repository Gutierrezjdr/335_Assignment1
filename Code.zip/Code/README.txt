You will use this exact Makefile for your Homework 1. Failure to do so will result in deduction of points.

To compile on terminal type
  make all

To delete executables and object file type
  make clean
